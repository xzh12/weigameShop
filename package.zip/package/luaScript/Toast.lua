require "json"

Toast = class("Toast")
Toast.__index = Toast

local winSize = cc.Director:getInstance():getWinSize()

function Toast.AlertWithBackground(message)
   local function removeOneself( labelNode )
                labelNode:removeFromParent(true)
    end
    if string.len(message)<=0 then
        --todo
        cclog("Toast.AlertWithBackground message is nil")
        return 
    end
     local world_lable = ccui.Text:create()
         world_lable:setText(message)
         world_lable:setFontName("")
         world_lable:setFontSize(25)

     local button_scale9 = ccui.Button:create()
        button_scale9:setTouchEnabled(false)
        button_scale9:loadTextures("black_button.9.png","black_button.9.png","")
        button_scale9:setTitleText(message)
        button_scale9:setTitleFontSize(25)
        button_scale9:setScale9Enabled(true)
        --button_scale9:setSize(cc.size(100, button_scale9:getVirtualRendererSize().height))
        button_scale9:setTitleColor(cc.c3b(169, 169, 169))
        button_scale9:setSize(cc.size(world_lable:getSize().width+40, world_lable:getSize().height+20))
        button_scale9:setPosition(cc.p(winSize.width/2, winSize.height/2-300))

        cc.Director:getInstance():getRunningScene():addChild(button_scale9)
        local array1 ={CCFadeIn:create(1),CCDelayTime:create(1),CCFadeOut:create(1),CCCallFuncN:create(removeOneself)}
        local seq1=CCSequence:create(array1)
        button_scale9:runAction(seq1) 

end

function Toast.Alert(message)
    local function removeOneself( labelNode )
                labelNode:removeFromParent(true)
    end
    if string.len(message)<=0 then
        --todo
        cclog("Toast.Alert message is nil")
        return 
    end

        local label = CCLabelTTF:create(message,"", 25)
        label:setPosition(cc.p(winSize.width/2, winSize.height/2-300))
        label:setColor(cc.c3b(169,169,169))
        cc.Director:getInstance():getRunningScene():addChild(label)
        local array1 ={CCFadeIn:create(1),CCDelayTime:create(1),CCFadeOut:create(1),CCCallFuncN:create(removeOneself)}
        local seq1=CCSequence:create(array1)
        label:runAction(seq1) 
end

function Toast.ShakeH(sender,...)
     local  arg = {...} 
     local  goLeft = cc.MoveBy:create(0.1, cc.p(arg[1] or -25,0) )
     local  back1=goLeft:reverse()
     local  goRight= cc.MoveBy:create(0.1, cc.p((arg[1] and -arg[1])or 25,0))
     local  back2=goRight:reverse()
     local  array1={goLeft,back1,goRight,back2,}
     sender:runAction(CCRepeat:create(CCSequence:create(array1), arg[2] or 1))

end
